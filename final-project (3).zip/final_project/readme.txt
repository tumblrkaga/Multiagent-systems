
### ID 2209 - Final Project ###

by Lodovico Giaretta and Abinaya Rajesh (Group 19)

# Super-quick Overview #

This project simulates a festival. Bars sell food and drinks, while music stars perform on top of stages.
Guests, either alone or in groups of friends, roam around the festival, listening to their favorite music and eating their favorite food.
Salesmen walk around the bars, trying to sell stuff to people while they are eating. Some people are ok with this, other are not.
Volunteers, belonging to some non-profit organisation, set up their stands in strategic locations in order to
stop as many guests as possible, while they move from one stage to another. They try to convince them to help their cause.
Some guests have more patience when listening to volunteers, while others will move away quickly.
Policemen patrol the festival and will send away any guest or group of guest that causes trouble (typically because they are drunk).
Policemen can see the the bad behaviour of guests, or they can be warned of it by other guests.
The amount of people present at the festival, along with their attitude, changes based on time of the day.
The simulation starts at 8 am on day 0 and runs until stopped, with each iteration representing 1 minute.

This project uses advanced features of GAMA, including the BDI architecture, the FSM architecture and multi-level simulations.

# To Run #

Make sure that GAMA version 1.8-rc2 or greater is being used.
Execute the experiment available in `final.experiment`.
All parameters are hardcoded in the sources, as they have been fine-tuned to provide a realistic simulation.
For a smoother, nicer simulation, browse to the end of `final.experiment` and comment-out the charts that
you are not interested in.

When reading the source, the following order is suggested:
  1) places.gaml
  2) guests.gaml
  3) others.gaml
  4) final.experiment

# Beware of Bugs #

GAMA has plenty of strange bugs.
Some bugs that can appear in this simulation are the following:
  1) Sometimes some of the top parts of stages (the purple boxes) don't appear. Refreshing the simulation solves the issue.
  2) Sometimes some of the charts stop being updated and then completely disappear (becoming blank)
  3) Sometimes all charts and the 3d view stop being updated, while the simulation keeps going, as the iteration counter grows very quickly,
     even when the iteration speed limiter is set to a low value.
     
 Bugs that were circumvented with some "hacks":
   1) The "wander" action of the "moving" skill does not appear to work in some context; more research on the causes is needed, but apparently
      the bug shows up only in micro-species defined inside a host species. The action was easily replaced with a randomised move.